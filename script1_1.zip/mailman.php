<?php

$mail = 'hasratalzalukhu@gmail.com'; // EMAIL KAMU

?>